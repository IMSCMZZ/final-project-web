<?php include 'connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Inventory Management</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style type="text/css">
    body {
        padding: 0px;
        margin: 0px;
        font-family: Arial, Helvetica, sans-serif;
        box-sizing: border-box;
        text-align: center;
        background-color: #f3f5f9; 
    }
    .table-container {
        margin: 0 auto; 
        width: 80%; 
        border: 2px solid #c5d4e0; 
        border-radius: 10px; 
        overflow: auto; 
        background-color: #ffffff; 
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); 
    }
    table {
        width: 100%; 
        border-collapse: collapse; 
    }
    th, td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #7fadff; 
        color: #ffffff; 
    }
    header {
        background-color: #4b89ff; 
        padding: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); 
    }
    a {
        text-decoration: none;
        color: #ffffff; 
    }
    h1 {
        margin: 0; /
        color: #ffffff; /
    }
    .profile-container {
        position: relative;
        display: inline-block;
    }
    .profile-img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        cursor: pointer;
    }
    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #ffffff; /
        min-width: 120px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        right: 0;
    }
    .dropdown-content a {
        color: #000000; 
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }
    .dropdown-content a:hover {
        background-color: #f1f1f1; /
    }
    .show {
        display: block;
    }
    .btn {
        padding: 10px 20px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        font-size: 16px;
        margin: 5px;
    }
    .btn a {
        color: #ffffff;
        text-decoration: none;
    }
    .btn.success {
        background-color: #4CAF50; 
    }
    .btn.success:hover {
        background-color: #45a049; 
    }
    .btn.info {
        background-color: #2196F3; 
    }
    .btn.info:hover {
        background-color: #0b7dda; 
    }
    .btn.danger {
        background-color: #f44336;
    }
    .btn.danger:hover {
        background-color: #da190b; 
    }
    .button-container {
        display: flex;
        justify-content: flex-end;
        margin: 20px 0;
        width: 80%;
        margin-left: auto;
        margin-right: auto;
    }

    
    .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
    }
    .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }
    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="date"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"],
        button[type="reset"] {
            background-color: #4b89ff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px 0;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover,
        button[type="reset"]:hover {
            background-color: #3a6eb1;
        }
    </style>
</head>
<body>
<header>
    <h1>Inventory Management</h1>
    <div class="profile-container">
        <img src="https://media.gettyimages.com/id/1490484750/photo/new-york-new-york-john-cena-attends-a-conversation-with-josh-horowitz-for-fast-x-at-the-92nd.jpg?s=612x612&w=0&k=20&c=ElH2YwqiYOsvlqhK-XRnF9p8JXR1qUnBWIn1gox_wKU=" alt="Profile" class="profile-img" onclick="toggleDropdown()">
        <div id="dropdownMenu" class="dropdown-content">
            <a href="#">Profile</a>
            <a href="#">Settings</a>
            <a href="login.php" onclick="return confirm('Are you sure you want to logout?')">Logout</a>
        </div>
    </div>
</header>
<br>
<h2>Product Inventory</h2>
<div class="button-container">
    <button class="btn success" id="addBtn">ADD</button>
</div>
<div class="table-container">
    <table>
        <tr>
            <th>Product Name</th>
            <th>Product ID</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Supplier</th>
            <th>Purchase Date</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php
        $query_data = "SELECT * FROM tbl_products";
        $get_data = mysqli_query($link, $query_data);
        $count = mysqli_num_rows($get_data);
        if ($count >= 1) {
            while ($row = mysqli_fetch_assoc($get_data)) {
        ?>
        <tr>
            <td><?=$row['ProductName'];?></td>
            <td><?=$row['ProductID'];?></td>
            <td><?=$row['Category'];?></td>
            <td><?=$row['Quantity'];?></td>
            <td><?=$row['Price'];?></td>
            <td><?=$row['Supplier'];?></td>
            <td><?=$row['PurchaseDate'];?></td>
            <td><a href="edit.php?changedata=<?php echo $row['id']; ?>" class="btn info">Edit</a></td>
            <td><a href="delete.php?id=<?php echo $row["id"]; ?>" class="btn danger">Delete</a></td>
        </tr>
        <?php
            }
        }
        ?>
    </table>
</div>


<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Add Product </h2>
        
        <form action="register.php" method="post">
            
            <?php if(!empty($errors)): ?>
                <div style="color: red;">
                    <?php foreach($errors as $error): ?>
                        <?php echo $error."<br>"; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            
            <label for="ProductName">Product Name:</label>
            <input type="text" name="ProductName"><br>
            <label for="ProductID">Product ID:</label>
            <input type="text" name="ProductID"><br>
            <label for="Category">Category:</label>
            <input type="text" name="Category"><br>
            <label for="Quantity">Quantity:</label>
            <input type="text" name="Quantity"><br>
            <label for="Price">Price:</label>
            <input type="text" name="Price"><br>
            <label for="Supplier">Supplier:</label>
            <input type="text" name="Supplier"><br>
            <label for="PurchaseDate">Purchase Date:</label>
            <input type="date" name="PurchaseDate"><br>
            <input type="submit" name="register" value="Add Product" class="btn success">
            <button type="reset" class="btn danger">Reset</button>
        </form>
    </div>
</div>

<script>
    
    var modal = document.getElementById("myModal");

    
    var btn = document.getElementById("addBtn");


    var span = document.getElementsByClassName("close")[0];

    
    btn.onclick = function() {
        modal.style.display = "block";
    }

    
    span.onclick = function() {
        modal.style.display = "none";
    }

    
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    function toggleDropdown() {
        var dropdown = document.getElementById("dropdownMenu");
        dropdown.classList.toggle("show");
    }

    window.onclick = function(event) {
        if (!event.target.matches('.profile-img')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }
</script>
</body>
</html>
