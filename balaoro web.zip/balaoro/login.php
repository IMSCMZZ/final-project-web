<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f5f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #4b89ff;
            padding: 20px 0;
            text-align: center;
            color: #fff;
            margin-bottom: 20px;
        }
        form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin: 0 auto;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 12px;
            border: none;
            background-color: #4b89ff;
            color: #fff;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #3a6eb1;
        }
        p {
            text-align: center;
            margin-top: 20px;
        }
        a {
            color: #4b89ff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .center {
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Product Management System</h1>
    </header>
    <div class="center">
        <form>
            <h2>Admin</h2>
            <input type="text" name="email" placeholder="Username or Email">
            <input type="password" name="password" placeholder="Password">
            <button type="submit" name="login">Login</button>
            <p><a href="#">Forgot Password?</a></p>
        </form>
    </div>
    <script>
    document.querySelector('form').addEventListener('submit', function(e) {
        e.preventDefault();
        var email = document.querySelector('input[name="email"]').value;
        var password = document.querySelector('input[name="password"]').value;
        
        if (email === "admin" && password === "admin123") {
            alert("Login Successful as Admin!");
            
            window.location.href = "index.php";
        } else {
            alert("Invalid credentials. Please try again.");
            
        }
    });
</script>

</body>
</html>
