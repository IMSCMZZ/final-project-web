<?php
include 'connect.php';

$errors = array(); 

if(isset($_POST['register'])){
    
    $fields = array('ProductName', 'ProductID', 'Category', 'Quantity', 'Price', 'Supplier', 'PurchaseDate');
    foreach($fields as $field){
        if(empty($_POST[$field])){
            $errors[] = "Please fill in all fields.";
            break;
        }
    }
    
    
    if(empty($errors)){
        $ProductName = mysqli_real_escape_string($link, $_POST['ProductName']);
        $ProductID = mysqli_real_escape_string($link, $_POST['ProductID']);
        $Category = mysqli_real_escape_string($link, $_POST['Category']);
        $Quantity = mysqli_real_escape_string($link, $_POST['Quantity']);
        $Price = mysqli_real_escape_string($link, $_POST['Price']);
        $Supplier = mysqli_real_escape_string($link, $_POST['Supplier']);
        $PurchaseDate = mysqli_real_escape_string($link, $_POST['PurchaseDate']);
        
        
        $insert_data = mysqli_query($link, "INSERT INTO tbl_products (ProductName, ProductID, Category, Quantity, Price, Supplier, PurchaseDate) 
        VALUES ('$ProductName', '$ProductID', '$Category', '$Quantity', '$Price', '$Supplier', '$PurchaseDate')");
        
        if($insert_data){
            echo "Product Added to Inventory Successfully";
            
            header("location: index.php");
            exit();
        } else {
            echo "Failed to Add Product to Inventory";
        }
    }
}
?>
